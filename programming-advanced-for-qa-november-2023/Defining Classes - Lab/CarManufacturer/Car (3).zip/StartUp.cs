﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main()
        {
            string make=Console.ReadLine();
            string model=Console.ReadLine();
            int year=int.Parse(Console.ReadLine());
            double fuelQuantity=double.Parse(Console.ReadLine()); 
            double fuelConsumption=double.Parse(Console.ReadLine());
            
            Car firstCar= new Car();
            Car secondCar= new Car(make,model,year);
            Car thirdCar= new Car(make,model,year,fuelQuantity,fuelConsumption);
           
            //car.Drive(2000);
            //Console.WriteLine($"Make: {car.Make}\nModel: {car.Model}\nYear: {car.Year}");
            //car.Drive(2000);
        }
    }
}
